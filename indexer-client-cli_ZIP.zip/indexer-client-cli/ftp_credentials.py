# class ftp_credentials:
#     hostname = "testwork7578342381.blob.core.windows.net"
#     username = "testwork7578342381.deepak525"
#     password = "jxFmH3oYMAlc1LhS2qsjs+MQkGpeGju8"


class ftp_credentials:
    hostname = "0.tcp.in.ngrok.io"
    username = "demo"
    password = "demo"
    port = 13368
