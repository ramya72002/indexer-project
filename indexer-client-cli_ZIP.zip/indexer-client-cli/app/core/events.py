from app.clients.auth import AuthClient

auth_client = AuthClient("credentials.json")