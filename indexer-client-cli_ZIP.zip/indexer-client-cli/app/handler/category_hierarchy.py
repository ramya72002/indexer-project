import pandas as pd

class CategoryHandler:
    def __init__(self) -> None:
         pass

    def get_category_hierarchy(self, category):
            parent = categories.get(category)
            if parent:
                hierarchy:list = self.get_category_hierarchy(parent)
                return [category]+hierarchy
            return [category]
        
    def categories(self,filepath):
        df = pd.read_csv(filepath)

        df.target = df.target.apply(str)
        df.source = df.source.apply(str)
        
        global categories

        categories = df.set_index("target")["source"].to_dict()

        all_categories = set([*categories.keys(),*categories.values()])


        hierarchy = {}

        for cat in all_categories:
            hierarchy[cat] = self.get_category_hierarchy(cat)
        category_hierarchy = {x:'>'.join(y[::-1]) for (x,y) in hierarchy.items() if 'b-' not in x}   
    #     brand_hierarchy = {x:y for (x,y) in hierarchy.items() if 'b-' in x}    
        return category_hierarchy