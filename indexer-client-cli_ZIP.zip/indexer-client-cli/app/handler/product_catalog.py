import pandas as pd
import numpy as np
from typing import List
from app.resources.product_catalog import catalog_files, converted_json_file, file_folder_path
from app.handler.category_hierarchy import CategoryHandler
from app.clients.indexer_api import IndexerAPIClient
from app.core.config import PRODUCT_CATALOG_ONE_TIME_FEED_BATCH_SIZE as BATCH_SIZE
from loguru import logger
from topiq_indexer.readers.json import JSONReader
from topiq_indexer.schema.events import IndexingEvent
from topiq_indexer.clients.auth import AuthClient


class ProductCatalogHandler:

    def __init__(self) -> None:
        self.category_handler = CategoryHandler()
        self.auth_client = AuthClient("./credentials.json")

    def download_files(self, sftp_source):

        for filename in sftp_source.client.listdir():

            file_split = filename.split("_")
            if file_split[0] in catalog_files:
                new_filename = file_split[0]+".csv"
                catalog_files[file_split[0]] = new_filename

                sftp_source.download(
                    filename, destination=f"./files/{new_filename}")

    def flat_list_dict(self, lis):
        d = {}
        for i in lis:
            for k, v in i.items():
                if k in d:
                    d[k].append(v)
                else:
                    d[k] = v
        return d

    def product_feature(self, filepath):
        pd1 = pd.read_csv(filepath)
        pd1 = pd1.drop(pd1[pd1["  productCode"] == "a"].index, axis=0)
        pd1["  productCode"] = pd1["  productCode"].astype(int)

        pd2 = pd1.groupby(["  productCode", "classificationAttributeCode"])["value"].apply(set).apply(list).reset_index(
            name='value')

        pd3 = pd2.drop(pd2[pd2["  productCode"] == "a"].index, axis=0)
        pd3["  productCode"] = pd3["  productCode"].astype(int)
        pd3["filters"] = [{k: v} for k, v in zip(
            pd3['classificationAttributeCode'], pd3['value'])]

        pd4 = pd3[["  productCode", "filters"]]
        pd4 = pd4.groupby(['  productCode'])['filters'].apply(
            list).reset_index(name="filters")

        pd4["filters"] = [self.flat_list_dict(x) for x in pd4["filters"]]

        return pd4

    def category_product_relation(self, cat_prod):
        multi_cat = cat_prod.groupby('target')['source'].apply(
            list).reset_index(name="cat_list")
        multi_cat["number_of_cat"] = multi_cat["cat_list"].apply(len)
        multi_cat = multi_cat.sort_values(by="number_of_cat", ascending=False)

        return multi_cat

    def category_master(self, filepath):
        cat_master = pd.read_csv(filepath)

        cat_names = {str(k): str(v) for k, v in zip(
            cat_master['code'], cat_master['name'])}

        return cat_names

    def category_hierarchy(self, filepath, category_master_file):
        cat_h = self.category_handler.categories(filepath)

        cat_cat = pd.DataFrame(cat_h.items(), columns=['categorie', 'path'])

        catt = pd.DataFrame(cat_cat.path.str.split('>').tolist(),
                            columns=['l1_category', 'l2_category', 'l3_category', 'l4_category'])
        catt['category'] = cat_cat['categorie'].values
        catt['path'] = cat_cat['path'].values

        cat_names = self.category_master(category_master_file)

        def names(val):
            return cat_names[str(val)]

        catt['category_names'] = catt['category'].apply(names)

        return catt

    def product_conversion(self):
        pd4 = self.product_feature(
            f'{file_folder_path}/{catalog_files["ProductFeature"]}')

        cat_prod = pd.read_csv(
            f'{file_folder_path}/{catalog_files["CategoryProductRelation"]}')
        multi_cat = self.category_product_relation(cat_prod)

        catt = self.category_hierarchy(
            f'{file_folder_path}/{catalog_files["CategoryCategoryRelation"]}',
            f'{file_folder_path}/{catalog_files["CategoryMaster"]}'
        )

        len(set(pd4['  productCode'].apply(str)))

        cat_cat_prod = pd.merge(catt, cat_prod, left_on='category', right_on='source', how='inner').drop(
            ['source', "creationTime", "modifiedTime"], axis=1)

        prod_1 = pd.merge(cat_cat_prod, pd4, left_on="target", right_on="  productCode", how="inner").drop(
            ["category", "target"], axis=1)
        prod_1.sort_values('l2_category')

        prod_master = pd.read_csv(
            f'{file_folder_path}/{catalog_files["ProductMaster"]}')

        prod_details = pd.merge(prod_master, prod_1, left_on="  CODE", right_on="  productCode", how="inner").drop(
            ["  CODE"], axis=1)
        prod_details.columns = [col.strip() for col in prod_details.columns]
        prod_details = prod_details.replace(np.nan, None)

        def delimiter(val):
            x = val.split('>')
            return x

        def thumb(val):
            if val is not None:
                index = val.find(":")
                return "https" + val[index:]
            else:
                return None

        prod_details['categories'] = prod_details['path'].apply(delimiter)
        prod_details['Thumbnail'] = prod_details['Thumbnail'].apply(thumb)

        prod_details.groupby('productCode')[
            'productCode'].count().sort_values(ascending=False)

        cat_det = prod_details[
            ['productCode', 'l1_category', 'l2_category', 'l3_category', 'l4_category', 'path', 'category_names',
             'categories']]

        cat_df_1 = cat_det.groupby("productCode", as_index=False).agg(
            {'l1_category': list, 'l2_category': list, 'l3_category': list, 'l4_category': list,
             'path': list, 'category_names': list, 'categories': list})

        def clean_cat(data):
            new_data = []
            for i in data:
                if i is not None:
                    new_data.append(i)
            if len(new_data) == 0:
                return None
            return new_data

        def flat_cat(data):
            new_data = []
            for i in data:
                new_data.extend(i)
            return new_data

        for i in cat_df_1.columns[1:-1]:
            cat_df_1[i] = cat_df_1[i].apply(clean_cat)

        cat_df_1['categories'] = cat_df_1['categories'].apply(flat_cat)

        prod_details = prod_details.drop(
            ['l1_category', 'l2_category', 'l3_category',
                'l4_category', 'path', 'category_names', 'categories'],
            axis=1)

        prod_details.drop_duplicates(inplace=True, subset=['productCode'])

        prod_details_final = pd.merge(
            prod_details, cat_df_1, on="productCode", how="inner")

        prod_details_final.shape

        prod_details_final.rename(
            columns={"l1_category": "l0_category", "l2_category": "l1_category", "l3_category": "l2_category",
                     "l4_category": "l3_category"}, inplace=True)

        prod_details_final.drop(['mop', 'mrp'], axis=1, inplace=True)

        prod_details_final.to_json(
            converted_json_file, orient='records', lines=True)

        return True

    def product_schema_handler(self):
        json_list = JSONReader(converted_json_file)

        indexer_api_client = IndexerAPIClient()

        count = 1
        for json_lines in json_list.read(batch_size=BATCH_SIZE):
            logger.info("Sending Http request to indexer api for batch: {} to {}",
                        count, count + BATCH_SIZE - 1)

            # events: List[IndexingEvent] = [IndexingEvent(
            #     event_type="PARTIAL_UPDATE", app_id=self.auth_client.credentials["app_id"], payload=x, upsert=True
            # ) for x in json_lines]

            res = indexer_api_client.http_publish(json_lines)
            print(res.json())

            count += BATCH_SIZE
            break

        return True
