from app.schema.source_feed import PincodeService, DeliveryModeEnum
from app.clients.pincode_api import PincodeAPIClient


class SourceFeedHandler:

    def __init__(self) -> None:
        pass
        
    def parse_data(data:dict):
        sourcing_rule_header = (data.get("Input")).get("SourcingRuleHeader")

        if sourcing_rule_header:

            sourcing_rule_header_key = sourcing_rule_header["SourcingRuleHeaderKey"]
            sourcing_rule_header_key_values = sourcing_rule_header_key.split(
                "_")

            delivery_mode = sourcing_rule_header_key_values[1]
            sourcing_rule_detail = sourcing_rule_header["SourcingRuleDetails"]["SourcingRuleDetail"]

            warehouses = []
            stores = []
            if delivery_mode == DeliveryModeEnum.HDEL:
                for source_rule in sourcing_rule_detail:
                    warehouses.append(source_rule["FromNodeKey"])
            elif delivery_mode in [DeliveryModeEnum.SDEL, DeliveryModeEnum.STOR]:
                for source_rule in sourcing_rule_detail:
                    stores.append(source_rule["FromNodeKey"])

            data_dict = PincodeService(
                organization_code=sourcing_rule_header["OrganizationCode"],
                region_key=int(sourcing_rule_header_key_values[0]),
                delivery_mode=delivery_mode,
                channel=sourcing_rule_header_key_values[2],
                item_classification=sourcing_rule_header_key_values[3],
                warehouses=warehouses,
                stores=stores
            )

            return data_dict.dict()

    def pincode_api_service(data: dict):
        pincode_api_client = PincodeAPIClient()

        return pincode_api_client.create_api(doc=data)
