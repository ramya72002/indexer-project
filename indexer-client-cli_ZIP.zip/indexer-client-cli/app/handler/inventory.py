from pymongo import MongoClient
from app.schema.inventory import InventoryService, Response, ExistRecord, ReadRequest
from app.core.config import MONGO_CONNECTION, MONGO_DATABASE, MONGO_INVENTORY_COLLECTION
from pymongo import MongoClient
from topiq_indexer.schema.events import IndexingEvent
from app.clients.indexer_api import IndexerAPIClient
from app.core.events import auth_client

class InventoryFeedHandler:

    def __init__(self) -> None:
        mongo_client = MongoClient(MONGO_CONNECTION)
        mongo_database = mongo_client[MONGO_DATABASE]
        self.inventory_collection = mongo_database[MONGO_INVENTORY_COLLECTION]

    def parse_data(self, data):
        inventory_item_header = data.get('InventoryItem')

        if inventory_item_header:

            availability_change_header_key = (inventory_item_header.get('AvailabilityChanges')).get('AvailabilityChange')
            availability_change_header_values = (availability_change_header_key['DistributionRuleId']).split('_')

            data_dict = InventoryService(
                product_id=int(inventory_item_header['ItemID']),
                channel=availability_change_header_values[0],
                store=availability_change_header_values[1],
                stock=int(availability_change_header_key['OnhandAvailableQuantity'])
            )
            
            return data_dict
    
    def find_and_modify(self, data):
        exist_record = ExistRecord(
            product_id=data.product_id,
            channel=data.channel
        )
        
        store_stock = {'stock.'+data.store : data.stock}

        updated_record = self.inventory_collection.find_one_and_update(
            exist_record.dict(),
            update={'$set': store_stock},
            upsert=True,
            return_document=True
        )

        return updated_record
    
    def read_record(self, data):
        record = ReadRequest(
            product_id=data.product_id,
            channel=data.channel
        )
        project = {
            '_id':0, 
            'product_id':1, 
            'stock':1
        }
        result = self.inventory_collection.find_one(record.dict(), project)
        if result:
            read_response = Response(
                productCode=result['product_id'],
                StockFlag=[key for key, val in result['stock'].items() if val>0]
            )

            return read_response.dict()
    
    def send_request(self, data):
        event = IndexingEvent(
            event_type="PARTIAL_UPDATE", 
            app_id=auth_client.credentials["app_id"], 
            payload=data, 
            upsert=True
        )
        indexer_api_client = IndexerAPIClient()

        return indexer_api_client.publish(doc=event)