from app.schema.pricing import PricingService
from topiq_indexer.schema.events import IndexingEvent
from app.clients.indexer_api import IndexerAPIClient
from app.core.events import auth_client

class PriceFeedHandler:
    
    def __init__(self) -> None:
        pass

    def parse_data(self,data):
        if data.get("ItemList"):
            item_list_header = (data.get('ItemList')).get('Item')
            list_price_header_values = (item_list_header.get('PricelistLineList')).get('PricelistLine')

            data_dict=PricingService(
                productCode=item_list_header.get('ItemID'),
                MOP=(list_price_header_values[0]).get('ListPrice'),
                MRP=(list_price_header_values[1]).get('ListPrice')
            )
        return data_dict.dict()
    
    def send_request(self, data):
        event = IndexingEvent(
            event_type="PARTIAL_UPDATE", 
            app_id=auth_client.credentials["app_id"], 
            payload=data, 
            upsert=True
        )
        indexer_api_client = IndexerAPIClient()

        return indexer_api_client.publish(doc=event)
    