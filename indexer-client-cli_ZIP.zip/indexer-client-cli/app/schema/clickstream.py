from pydantic import BaseModel
from typing import Optional
from resources.event import Event


class Attributes(BaseModel):
    link_name: Optional[str] = None
    search_event: int
    cart_event: int
    order_event: int
    link_type: Optional[str] = None
    product_rank: int
    link_position: Optional[str] = None
    auto_suggestion_prefix: Optional[str] = None
    search_term: Optional[str] = None
    quantity: Optional[str] = None
    product_id: Optional[str] = None
    price: Optional[str] = None
    auto_suggestion_term: Optional[str] = None
    click_position: Optional[str] = None
    buynow_event: int
    product_rank: Optional[int] = 0
    product_view: int


class BaseEvent(BaseModel):
    event_time: str
    session_id: Optional[str] = None
    session_user_id: Optional[str] = None
    previous_page: Optional[str] = None
    device: str
    location: str
    event_type: Optional[str] = None


class FileAttributes(BaseEvent):
    link_name: Optional[str] = None
    search_event: int
    cart_event: int
    order_event: int
    link_type: Optional[str] = None
    product_rank: int
    link_position: Optional[str] = None
    auto_suggestion_prefix: Optional[str] = None
    search_term: Optional[str] = None
    quantity: Optional[str] = None
    product_id: Optional[str] = None
    price: Optional[str] = None
    auto_suggestion_term: Optional[str] = None
    click_position: Optional[str] = None
    buynow_event: int
    product_rank: Optional[int] = 0
    product_view: int


class SearchEvent(BaseEvent):
    search_term: Optional[str]
    search_res_count: Optional[str] = 0


class AutoSuggestEvent(BaseEvent):
    position: Optional[str]
    auto_suggestion_prefix: str
    auto_suggestion_term: str


class FilterEvent(BaseEvent):
    search_term: str
    filter: Optional[list] = None


class SortEvent(BaseEvent):
    search_term: Optional[str] = None
    sort: str


class PDPEvent(BaseEvent):
    search_term: Optional[str] = None
    product_id: Optional[str] = None
    click_position: Optional[str] = None


class WhishlistEvent(BaseEvent):
    search_term: Optional[str] = None
    product_id: Optional[str] = None


class CartEvent(BaseEvent):
    search_term: Optional[str] = None
    product_id: Optional[str] = None


class OrderEvent(BaseEvent):
    search_term: Optional[str] = None
    sale_info: Optional[dict] = None