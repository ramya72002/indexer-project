from enum import Enum
from typing import List, Optional

from pydantic import BaseModel


class DeliveryModeEnum(str, Enum):
    HDEL = "HDEL"
    SDEL = "SDEL"
    STOR = "STOR"


class ItemClassificationEnum(str, Enum):
    SA = "SA"
    LA = "LA"
    SA_LTD = "SA-LTD"
    LA_LTD = "LA-LTD"


class ChannelEnum(str, Enum):
    EC = "EC"
    RS = "RS"


class PincodeService(BaseModel):
    organization_code: str = "croma"
    region_key: int
    delivery_mode: DeliveryModeEnum
    channel: ChannelEnum
    item_classification: ItemClassificationEnum
    warehouses: List[str]
    stores: List[str]