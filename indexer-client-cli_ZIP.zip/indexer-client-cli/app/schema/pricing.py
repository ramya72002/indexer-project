from pydantic import BaseModel

class PricingService(BaseModel):
    productCode:int
    MOP:float
    MRP:float
