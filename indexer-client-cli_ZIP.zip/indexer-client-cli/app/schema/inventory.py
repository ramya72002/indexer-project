from typing import List
from pydantic import BaseModel

class ExistRecord(BaseModel):
    product_id : int
    channel : str

class Response(BaseModel):
    productCode : int
    StockFlag : List[str]

class InventoryService(BaseModel):
    product_id : int
    channel : str
    store : str
    stock : int

class ReadRequest(ExistRecord):
    pass