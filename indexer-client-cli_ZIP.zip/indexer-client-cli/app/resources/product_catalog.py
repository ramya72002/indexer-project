catalog_files = {
    "CategoryCategoryRelation": "",
    "CategoryMaster": "",
    "CategoryProductRelation": "",
    "ProductFeature": "",
    "ProductMaster": ""
}

watch_file = "CatalogTestFile_*.txt"

file_folder_path = "./files/one_time_feed_csv"

converted_json_file = "./files/one_time_feed.json"
