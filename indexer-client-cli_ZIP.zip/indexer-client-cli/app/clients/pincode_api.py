from topiq_indexer.targets.http import HTTPTarget
from app.core.config import PINCODE_SERVICE_URL, PINCODE_SERVICE_CREATE_DATA


class PincodeAPIClient:
    def __init__(self) -> None:
        create_api_url = f"{PINCODE_SERVICE_URL}{PINCODE_SERVICE_CREATE_DATA}"
        headers = {"Content-Type": "application/json",
                   "Authorization": "Bearer "}

        self.create_api_target = HTTPTarget(create_api_url, headers=headers)

    def create_api(self, doc: dict):
        return self.create_api_target.send(doc)
