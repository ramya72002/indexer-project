from topiq_indexer.targets.http import HTTPTarget
from app.core.config import INDEXER_BASE_URL, INDEXER_PUBLISH, INDEXER_BATCH_PUBLISH
from app.core.events import auth_client
from topiq_indexer.targets.bulk_indexer import BulkIndexer
from topiq_indexer.schema.events import IndexingEvent
from typing import List


class IndexerAPIClient:
    def __init__(self) -> None:
        publish_url = f"{INDEXER_BASE_URL}{INDEXER_PUBLISH}"
        batch_publish_url = f"{INDEXER_BASE_URL}{INDEXER_BATCH_PUBLISH}"
        self.publish_target = HTTPTarget(publish_url, auth_client.headers)
        self.batch_publish_target = HTTPTarget(
            batch_publish_url, auth_client.headers)
        self.bulk_indexer = BulkIndexer(self.batch_publish_target)

    def publish(self, doc: IndexingEvent):
        return self.publish_target.send(doc.dict())

    def batch_publish(self, docs: List[IndexingEvent]):
        self.bulk_indexer.bulk(docs)

    def http_publish(self, data: List):
        body = {
            "event_type": "PARTIAL_UPDATE",
            "app_id": auth_client.credentials["app_id"],
            "payload": data,
            "upsert": True
        }
        return self.batch_publish_target.send(body)
