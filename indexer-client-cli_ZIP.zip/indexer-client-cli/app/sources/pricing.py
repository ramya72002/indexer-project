from topiq_indexer.sources.mq import MQSource
from topiq_indexer.readers.xml import XMLReader
from app.handler.pricing import PriceFeedHandler
from topiq_indexer.core.config import (
    MQ_CHANNEL, MQ_HOST, MQ_MANAGER, MQ_PORT, MQ_PRICE_FEED_QUEUE)
from loguru import logger

source = MQSource(MQ_MANAGER, MQ_CHANNEL, MQ_HOST, MQ_PORT)


@source.watch(MQ_PRICE_FEED_QUEUE, 50)
def price_feed(msg):

    for message in msg['messages']:
        reader = XMLReader(text=message.decode())
        json_data = reader.to_dict()

        if json_data.get("ItemList"):
            price_feed_handler=PriceFeedHandler()

            payload = price_feed_handler.parse_data(data=json_data)

            create_record=price_feed_handler.send_request(payload)

            logger.info("HTTP Request Sent Successfully {}",create_record.json())

