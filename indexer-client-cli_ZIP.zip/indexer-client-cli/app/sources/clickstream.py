# from topiq_indexer.sources.mq import MQSource
from topiq_indexer.sources.sftp import SFTPSource
from topiq_indexer.readers.csv import CSVReader
from ftp_credentials import ftp_credentials as ftp_creds
from resources.croma_mappings import mapped_fields, map_event_fields
from resources.event import Event
from utils.event import find_event
from resources.models import models
from app.schema.clickstream import BaseEvent
import json
import sys

source = SFTPSource(
    hostname=ftp_creds.hostname,
    username=ftp_creds.username,
    password=ftp_creds.password,
    port=ftp_creds.port
)

def get_event(attributes):
    fields = mapped_fields(attributes)
    event_name = find_event(fields)
    Model: BaseEvent = models.get(event_name)
    if not Model:
        return None
    fields["event_type"] = event_name
    final = map_event_fields(fields, event_name)
    return Model(**final).dict()

@source.watch('Total_Data.csv')
def onchange(filename):
    file = source.open(filename)
    reader = CSVReader(file)
    for lines in reader.read():
        batch = []
        for line in lines:
            try:
                d = get_event(line)
            except Exception as e:
                print(e, line)
                sys.exit(0)
            if not d:
                continue
            if d["event_type"] == Event.AUTOSUGGEST:
                print(d)
