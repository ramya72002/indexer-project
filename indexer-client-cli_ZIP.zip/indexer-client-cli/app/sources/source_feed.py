from topiq_indexer.sources.mq import MQSource
from topiq_indexer.readers.xml import XMLReader
from loguru import logger
from app.handler.source_feed import SourceFeedHandler
from topiq_indexer.core.config import (
    MQ_CHANNEL, MQ_HOST, MQ_MANAGER, MQ_PORT, MQ_SOURCE_FEED_QUEUE)

source = MQSource(MQ_MANAGER, MQ_CHANNEL, MQ_HOST, MQ_PORT)


@source.watch(MQ_SOURCE_FEED_QUEUE, 50)
def source_feed(msg):

    for message in msg["messages"]:
        reader = XMLReader(text=message.decode())
        json_data = reader.to_dict()
        print(json_data)
        if json_data.get("Input"):
            source_feed_handler = SourceFeedHandler()
            parsed_data = source_feed_handler.parse_data(data=json_data)

            create_record = source_feed_handler.pincode_api_service(
                parsed_data)

            logger.info("Http request sent successfully: {}",
                        create_record.json())
