from topiq_indexer.sources.mq import MQSource
from topiq_indexer.readers.xml import XMLReader
from loguru import logger
from app.core.config import (
    MQ_CHANNEL, MQ_HOST, MQ_MANAGER, MQ_PORT, MQ_INVENTORY_FEED_QUEUE)
from app.handler.inventory import InventoryFeedHandler
from app.clients.indexer_api import IndexerAPIClient

source = MQSource(MQ_MANAGER, MQ_CHANNEL, MQ_HOST, MQ_PORT)

@source.watch(MQ_INVENTORY_FEED_QUEUE, 50)
def inventory_feed(msg):

    for message in msg["messages"]:
        reader = XMLReader(text=message.decode())
        json_data = reader.to_dict()

        if json_data.get("InventoryItem"):
            inventory_feed_handler = InventoryFeedHandler()

            parsed_data = inventory_feed_handler.parse_data(data=json_data)
            upsert_flag = inventory_feed_handler.find_and_modify(data=parsed_data)
            
            payload = inventory_feed_handler.read_record(data=parsed_data)

            create_record = inventory_feed_handler.send_request(payload)

            logger.info("HTTP Request Sent Successfully {}",create_record.json())