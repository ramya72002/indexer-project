from topiq_indexer.sources.sftp import SFTPSource
from ftp_credentials import ftp_credentials as ftp_creds
from loguru import logger
from app.resources.product_catalog import watch_file
from app.handler.product_catalog import ProductCatalogHandler

sftp_source = SFTPSource(
    hostname=ftp_creds.hostname,
    username=ftp_creds.username,
    password=ftp_creds.password,
    port=ftp_creds.port
)

product_handler = ProductCatalogHandler()


@sftp_source.watch(watch_file)
def read_file(file):
    logger.info("Files downloading start")
    product_handler.download_files(sftp_source)
    logger.info("Files downloaded successfully")

    logger.info("Catalog CSV files conversion start")
    result = product_handler.product_conversion()

    if result:
        logger.info("Files converted successfully into single json")

        logger.info("Catalog schema sends to indexer service start")
        res = product_handler.product_schema_handler()
        if res:
            logger.info("Catalog schema successfully sent to indexer service")
