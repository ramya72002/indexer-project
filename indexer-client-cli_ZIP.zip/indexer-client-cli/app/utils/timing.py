from threading import Timer, Thread


def set_interval(func, sec):
    def func_wrapper():
        func()
        set_interval(func, sec)
    t = Timer(sec, func_wrapper)
    t.start()
    return t


def set_timeout(func, sec):
    r = Timer(sec, func)
    r.start()
    return r

def set_immediate(func, args):
    r = Thread(target=func, args=(args,))
    r.start()
    return r
