from resources.event import Event, Attribute
from schema.events import Attributes


def find_event(fields):
    obj = Attributes(**fields)

    if obj.link_name == Attribute.whishlist:
        return Event.WHISHLIST
    elif obj.cart_event > 0:
        return Event.CART
    elif obj.search_event > 0 or obj.buynow_event > 0:
        return Event.SEARCH
    elif obj.order_event > 0:
        return Event.ORDER
    elif obj.link_type == Attribute.filter:
        return Event.FILTER
    elif obj.product_rank > 0 or (type(obj.product_rank) == int and obj.product_rank > 0):
        return Event.PDP
    elif obj.link_position == Attribute.sort:
        return Event.SORT
    elif len(obj.auto_suggestion_prefix) > 2:
        return Event.AUTOSUGGEST
    else:
        return "UnknownEvent"
