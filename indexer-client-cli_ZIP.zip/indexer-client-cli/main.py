# from topiq_indexer.core.config import INDEXER_BASE_URL
import os
os.environ["PYTHONPATH"] = os.path.join(os.getcwd(),"core")+":"+os.environ["PYTHONPATH"]

from topiq_indexer.sources.file import FileSource
from topiq_indexer.sources.ftp import FTPSource
from topiq_indexer.clients.auth import AuthClient
from topiq_indexer.clients.indexer import IndexerClient
import time

from ftp_credentials import ftp_credentials as ftp_creds


source = FileSource("/Users/ashutoshsinghai/Downloads/raw_catalog.json")

# ftp_source = FTPSource(
#     hostname=ftp_creds.hostname,
#     username=ftp_creds.username,
#     password=ftp_creds.password
# )

# print("CONNECTED")

client = AuthClient("credentials.json")

print(client.credentials)

# print(client.headers)

indexer_client = IndexerClient(auth_client=client)

# print("INIT INDEXER")


# def changed(filename):
#     print(f"A Changed {filename}, sleeping for 20 sec")
#     time.sleep(20)
#     print("A END")


# def modified(filename):
#     print(f"{filename} Changed {filename}")
#     print(f"{filename} sleeping for 10 sec")
#     time.sleep(10)
#     print(f"{filename} sleeping for another 10 sec")
#     time.sleep(10)
#     print(f"{filename} sleeping for another 10 sec")
#     time.sleep(10)
#     print(f"{filename} END")


# def read_file(filename):
#     i = 0
#     # ftp_source.open()
#     wr = open("writeFile.json","w")
#     for line in ftp_source.read("sample.json"):
#         i += 1
#         # print("DONE",i)
#         # print(line)
#         wr.write(line)
#     print("DONE")
#     start = time.time()
    # print("CHANGED")
    # ftp_source.upload("small.json","very_big.json")
    # print("DOWNLOADED",time.time()-start)

        # print(data)

# ftp_source.onchange("raw_catalog.json",modified)

# ftp_source.onchange("sample.json",read_file)

# source.onchange(changed)

print("AFTER WATCH")

# time.sleep(20)

# Add another listener
# source.onchange(modified)
# print(client.credentials,client.tokens)

for doc in source.docs:
    indexer_client.add(doc)

# print("TOTAL DOCS",indexer_client.docs_count)
# print("indexed DOCS",indexer_client.indexed_docs)

# time.sleep(3)
# print("indexed DOCS finally",indexer_client.indexed_docs)

# os._exit(0)


# for doc in ftp_source.batches:
#     print(doc)

# print("AShuTOSH",INDEXER_BASE_URL,FTPClient)
