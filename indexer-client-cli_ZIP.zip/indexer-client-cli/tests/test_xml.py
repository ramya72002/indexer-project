from topiq_indexer.readers.xml import XMLReader

d = XMLReader(filepath="test.xml")

print(d.to_json("testxml.json"))