from helper import parse_data_params, pincode_service_params
from app.handler.source_feed import SourceFeedHandler


async def test_parse_function_flowsuccess():

    json_payload = parse_data_params["success_flow"]["payload_body"]
    expected_output = parse_data_params["success_flow"]["expected_output"]

    result = SourceFeedHandler.parse_data(data=json_payload)

    assert result == expected_output

async def test_pincode_service_function_flowsuccess():

    json_payload = pincode_service_params["success_flow"]["payload_body"]
    expected_output = pincode_service_params["success_flow"]["expected_output"]

    result = SourceFeedHandler.pincode_api_service(data=json_payload)

    assert result.json() == expected_output