parse_data_params = {
    "success_flow": {
        "payload_body": {
            "Input": {
                "SourcingRuleHeader": {
                    "Action": "Update",
                    "FulfillmentType": "HDEL",
                    "ItemGroupCode": "PROD",
                    "OrderSourcingClassification": "EC",
                    "OrganizationCode": "CROMA",
                    "Purpose": "SOURCING",
                    "RegionKey": "400038",
                    "SellerOrganizationCode": "CROMA",
                    "SourcingRuleHeaderKey": "400038_HDEL_EC_LA",
                    "SourcingRuleDetails": {
                        "Reset": "N",
                        "SourcingRuleDetail": [
                            {
                                "FromNodeKey": "E021",
                                "ProcureToShipAllowed": "N",
                                "SeqNo": "0",
                                "SourcingRuleDetailKey": "400038_HDEL_EC_LA_1",
                                "TemplateType": "Specific_Node"
                            },
                            {
                                "FromNodeKey": "D015",
                                "ProcureToShipAllowed": "N",
                                "SeqNo": "1",
                                "SourcingRuleDetailKey": "2022090210572351774701",
                                "TemplateType": "Specific_Node"
                            }
                        ]
                    }
                }
            }
        },
        "expected_output": {
            "organization_code": "CROMA", 
            "region_key": 400038, 
            "delivery_mode": "HDEL", 
            "channel": "EC", 
            "item_classification": "LA", 
            "warehouses": ["E021", "D015"], "stores": []
        }
    }
}

pincode_service_params = {
    "success_flow": {
        "payload_body": {
            "organization_code": "CROMA", 
            "region_key": 400038, 
            "delivery_mode": "HDEL", 
            "channel": "EC", 
            "item_classification": "LA", 
            "warehouses": ["E021", "D015"], "stores": []
        },
        "expected_output": {"message": "Source data successfully created"}
    }
}