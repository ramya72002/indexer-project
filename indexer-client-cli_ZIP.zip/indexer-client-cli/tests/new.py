import sys

sys.path.append("..")

from app.clients.indexer_api import IndexerAPIClient
from topiq_indexer.sources.filev1 import FileSystemSource
from topiq_indexer.readers.json import JSONReader
from typing import List
from topiq_indexer.schema.events import IndexingEvent

source = FileSystemSource()

indexer_client = IndexerAPIClient()

@source.watch("/Users/ashutoshsinghai/Downloads/croma_data.json", 1, 2, 3)
def change(filepath):
    reader = JSONReader(filepath)
    for lines in reader.read(20000):
        # print("LINES", len(lines))
        events: List[IndexingEvent] = [IndexingEvent(
            event_type="CREATE", app_id="e2c8ae75-274e-4ccc-aed9-c0916ef4ee66", payload=x, upsert=True) for x in lines]
        # print("EVENTS", len(events))
        indexer_client.batch_publish(events)
        
