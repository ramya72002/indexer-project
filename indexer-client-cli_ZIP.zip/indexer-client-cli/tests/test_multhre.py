# Online Python compiler (interpreter) to run Python online.
# Write Python 3 code in this online editor and run it.
from concurrent.futures import ThreadPoolExecutor
import time

def taskA():
    print("started A")
    for i in range(10):
        if i==7:
            print("A on 7")
        time.sleep(1)
    print("finished A")
        
def taskB():
    print("started B")
    for i in range(10):
        time.sleep(2)
    print("finished B")

def taskC():
    print("started C")
    for i in range(10):
        time.sleep(1)
    print("finished C")

with ThreadPoolExecutor(max_workers=3) as executor:
    executor.submit(taskA)
    executor.submit(taskB)
    executor.submit(taskC)