from topiq_indexer.sources.filev1 import FileSystemSource
import json
from typing import List
from io import FileIO
from topiq_indexer.readers.json import JSONReader
from topiq_indexer.targets.http import HTTPTarget
from topiq_indexer.clients.auth import AuthClient
from topiq_indexer.targets.bulk_indexer import BulkIndexer
from topiq_indexer.schema.events import IndexingEvent

source = FileSystemSource()

auth_client = AuthClient("credentials.json")

http_target = HTTPTarget(
    "https://api-dev.topiq.ai/indexer-api/batch/publish", headers={"Authorization": "Bearer "+auth_client.tokens["access_token"]})

bulk_indexer = BulkIndexer(target=http_target)


def callback(file):
    c = 0
    with source.open("/Users/ashutoshsinghai/Downloads/raw_catalog.json") as f:
        for line in f:
            c += len(json.loads(line))

    print("chars", c)


def callback2(file):
    print("CHANGED", file)


@source.watch("/Users/ashutoshsinghai/Downloads/sample.json")
def change(filepath):
    with source.open("/Users/ashutoshsinghai/Downloads/sample.json") as f:
        for line in f:
            print(line)
    print("FILE CHANGED 1223", filepath)


@source.watch("/Users/ashutoshsinghai/Downloads/raw_catalog.json", 1, 2, 3)
def change(filepath):
    reader = JSONReader(filepath)
    for lines in reader.read(20000):
        # print("LINES", len(lines))
        events: List[IndexingEvent] = [IndexingEvent(
            event_type="CREATE", app_id="e2c8ae75-274e-4ccc-aed9-c0916ef4ee66", payload=x, upsert=True) for x in lines]
        # print("EVENTS", len(events))
        bulk_indexer.bulk(events)
