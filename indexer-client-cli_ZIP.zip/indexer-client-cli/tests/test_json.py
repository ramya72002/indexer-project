from topiq_indexer.readers.json import JSONReader

d = JSONReader('/Users/ashutoshsinghai/Downloads/ibo_prod_data.json')

c = 0

for lines in d.read():
    # c += len(lines)
    x = [x["_id"] for x in lines]
    print(x)

print(c)