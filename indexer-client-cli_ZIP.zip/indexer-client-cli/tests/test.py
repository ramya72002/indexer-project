# from topiq_indexer.sources.kafkaS import KafkaSource

# source = KafkaSource()

# source.watch()

import json 
from kafka import KafkaConsumer


if __name__ == '__main__':
    # Kafka Consumer 
    consumer = KafkaConsumer(
        'kafka-test',
        bootstrap_servers='pkc-lq8v7.eu-central-1.aws.confluent.cloud:9092',
        auto_offset_reset='earliest'
    )
    for message in consumer:
        print(json.loads(message.value))