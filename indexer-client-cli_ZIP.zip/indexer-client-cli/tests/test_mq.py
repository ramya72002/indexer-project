from topiq_indexer.sources.mq import MQSource

source = MQSource('QM1','DEV.APP.SVRCONN','192.168.0.15','1414')

@source.watch('DEV.QUEUE.1',50)
def func(d):
    print(d)