from topiq_indexer.readers.csv import CSVReader
import io

# f = io.StringIO("Name,Designation,age,salary\nAlice,Programmer,23,110000\nBob,Executive,28,120000\nABs,CEO,38,920000")

# f = open("test.csv")

d = CSVReader(file="test.csv")

# r = d.parse('')

# print(d.readline())
# print(d.read(batch_size=1))
# print(d.read(batch_size=1))
# print(d.read(batch_size=1))
# print(d.read(batch_size=1))

for lines in d.read():
    print(lines)