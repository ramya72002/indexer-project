import pymqi
import sys

queue_manager = pymqi.connect('QM1', 'DEV.APP.SVRCONN','0.tcp.in.ngrok.io(17192)')
q = pymqi.Queue(queue_manager, 'DEV.QUEUE.1')

# a = q.get_handle()

# print(dir(q))
while True:
    try:
        m = q.get()
        print(m)
    except:
        sys.exit(0)
        