import pymqi
import sys

queue_manager = pymqi.connect('QM1', 'DEV.APP.SVRCONN','0.tcp.in.ngrok.io(17192)')

q = pymqi.Queue(queue_manager, 'DEV.QUEUE.1')

argv = sys.argv[1:]

for i in range(int(argv[0])):
    q.put(f'Hello from Python {i} !')