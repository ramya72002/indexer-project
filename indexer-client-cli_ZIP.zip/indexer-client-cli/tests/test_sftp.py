from topiq_indexer.sources.sftp import SFTPSource
from ftp_credentials import ftp_credentials as ftp_creds
from topiq_indexer.readers.csv import CSVReader

ftp_source = SFTPSource(
    hostname=ftp_creds.hostname,
    username=ftp_creds.username,
    password=ftp_creds.password,
    port=ftp_creds.port
)


@ftp_source.watch("CategoryMaster_*.csv")
def changefile(filename):
    print('filename: ', filename)
    # f = ftp_source.open("CategoryMaster_13122022_0230.csv")
    # print('f: ',f)
    # reader = CSVReader(f)
    # for lines in reader.read():
    #     print(lines)
