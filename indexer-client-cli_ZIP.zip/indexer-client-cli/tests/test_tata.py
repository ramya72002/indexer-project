import requests

SERVICES_URL = "https://internal-af2d45fb9429746509b1067d3567ff77-437995855.ap-south-1.elb.amazonaws.com"


url = f"{SERVICES_URL}/insearch-service-spellcheck/spellcheck?query=watches"
result = requests.get(url=url, verify=False)
spell_check_response = result.json()

normalized_query = spell_check_response["normalized_query"]
qps_url = f"{SERVICES_URL}/insearch-service-query-parser/parser-v3?prob_thresh=0.3&query={normalized_query}"
qps_result = requests.get(url=qps_url, verify=False)
qps_response = qps_result.json()

qps_value = qps_response["filters"][0]["values"]

print(qps_value)

# category_list = await user_details_repo.get_users_details(user_id)
# common_category = set(category_list[0].get("categories")).intersection(
#     set(qps_value)
# )
# common_category_list = list(common_category)