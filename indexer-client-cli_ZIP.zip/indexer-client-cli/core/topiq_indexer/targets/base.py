class Target:
    def send(self):
        pass

    def bulk_send(self):
        pass