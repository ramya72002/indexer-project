from typing import Union, Dict, List
import requests
from requests import Session, Response
from pydantic import BaseModel, Field
from topiq_indexer.utils.multithreading import execute_parallel
from concurrent.futures import ThreadPoolExecutor
import copy
from threading import Thread

class HTTPTarget:
    def __init__(self, url, headers) -> None:
        if not headers.get("Authorization") or headers.get("authorization"):
            raise ValueError(
                "Authorization header is required for HTTP target. If not applicable, send a dummy value")
        self.url = url
        self.headers = headers
        self.failed = []

    def send(self, body: Union[Dict, List], headers: Dict={}):
        response = requests.post(self.url, json=body, headers={
                                 **self.headers, **headers})
        return response

    def __send_single_bulk(self, item: Union[Dict, List]):
        # print("SENDING",self.url, self.headers)
        res: Response = requests.post(self.url, headers=self.headers, json=item)
        if res.status_code != 200:
            self.failed.append({"response": res.text, "body": item})
            print("ERRORRRR", res.text)
        else:
            # print("SUCCESS")
            pass

    def bulk_send(self, body: List):
        """_summary_

        Args:
            body (List): _description_

        Returns:
            failed: List[Dict] list of failed documents
        """
        # execute_parallel(self.__send_single_bulk, body)
        with ThreadPoolExecutor(max_workers=15) as executor:
            executor.map(self.__send_single_bulk,body)
        # print("SUCCESS with",sum([len(x["payload"]) for x in body]),"docs. Failed",len(self.failed),"docs")
        failed = copy.deepcopy(self.failed)
        self.failed = []
        return failed
