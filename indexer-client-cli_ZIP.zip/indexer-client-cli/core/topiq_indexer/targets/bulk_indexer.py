from .base import Target
from typing import List, Any, Dict, Callable
import json
from copy import deepcopy
from topiq_indexer.schema.events import IndexingEvent
import time
from tqdm import tqdm

def batch_builder(docs: List[IndexingEvent]):
    payload = [x.payload for x in docs]
    return {
        "event_type": docs[0].event_type,
        "app_id": docs[0].app_id,
        "payload": payload,
        "upsert": docs[0].upsert
    }


class BulkIndexer:
    def __init__(self, target: Target, batch_size_mb=5, batch_builder: Callable = batch_builder) -> None:
        self.target = target
        self.max_batch_size = batch_size_mb*1024**2
        self.batch_builder = batch_builder
        self.indexed_docs = 0
        self.progress_init = False
        self.pbar = None

    def bulk(self, docs: List[IndexingEvent]):
        # print("STARTING")
        if not self.progress_init:
            self.progress_init = True
            self.pbar = tqdm()
        event_batches: Dict[str, List[dict]] = {}
        batch_lengths: Dict[str, int] = {}
        batches = []
        for doc in docs:
            doc: IndexingEvent = doc
            doc_length = len(json.dumps(doc.dict()))
            batch_length = batch_lengths.get(doc.event_type,0)
            # print("BATCH LENGTH",batch_length)
            batch = event_batches.get(doc.event_type, [])
            if len(batches) >= 10:
                transformed_batches = [
                    self.batch_builder(x) for x in batches]
                self.target.bulk_send(transformed_batches)
                docs_in_batch = sum([len(x["payload"]) for x in transformed_batches])
                self.pbar.update(docs_in_batch)
                self.indexed_docs = docs_in_batch
                # print("BATCHES of len",len(batches),"TOtal docs",len([len(x) for x in batches]))
                # print("INdexed",self.indexed_docs)
                # print(transformed_batches)
                batches = []
            # print("BATCHES", batches)
            if (batch_length+doc_length) > self.max_batch_size:
                # print("MAX EXCEEDED")
                # print("BATCH LENGTH EXCEEDED",batch_length,"docs",len(batch),len(batches),[len(json.dumps(x.dict())) for x in batch])
                batches.append(deepcopy(batch))
                batch_lengths[doc.event_type] = 0
                event_batches[doc.event_type] = []

            if batch:
                event_batches[doc.event_type].append(doc)
                batch_lengths[doc.event_type] += doc_length
                # print("ADDING")
            else:
                event_batches[doc.event_type] = [doc]
                batch_lengths[doc.event_type] = doc_length
        # print("Last few")
        for event_type in event_batches:
            if len(event_batches[event_type]) > 0:
                batches.append(event_batches[event_type])
        if len(batches) > 0:
            transformed_batches = [self.batch_builder(x) for x in batches]
            # print("TRANSFORMED")
            self.target.bulk_send(transformed_batches)
            docs_in_batch = sum([len(x["payload"]) for x in transformed_batches])
            self.pbar.update(docs_in_batch)
            self.indexed_docs = docs_in_batch
            # print("INdexed final",self.indexed_docs)
            batches = []
