from .base import FileReader
from typing import List
import json


class JSONReader(FileReader):

    def __init__(self, file=None) -> None:
        if file:
            if type(file) != str:
                self.file = file
            else:
                self.file = open(file)

    def read(self, batch_size=10):
        for lines in super().read(self.file, batch_size):
            lines = [json.loads(line) for line in lines]
            yield lines
