import io
from .base import FileReader
import csv
from typing import List, Dict
from itertools import islice


class CSVReader(FileReader):
    def __init__(self, file=None, headers: List[str] = None) -> None:
        if file:
            if type(file) != str:
                self.file = file
            else:
                self.file = open(file, encoding="utf-8-sig")

            reader = csv.reader(self.file)
            self.headers = [x.encode('utf-8') for x in next(reader, None)]
            self.headers = [x.decode('utf-8-sig') for x in self.headers]
            print("HEADERS",self.headers)

        if headers:
            self.headers = headers

    def read(self, batch_size=10):
        while True:
            lines = list(islice(self.file, batch_size))
            if not lines:
                break
            lines = [x.encode('utf-8') for x in lines]
            lines = [x.decode('utf-8-sig') for x in lines]
            yield self.parse("".join(lines))

    def readline(self, number_of_lines=1):
        if number_of_lines > 1:
            lines = list(islice(self.file, number_of_lines))
            return self.parse("".join(lines))
        return self.parse(self.file.readline())[0]

    def parse(self, lines: str, delimiter=',') -> List[Dict]:
        # print("LINES",lines)
        """parses the string and converts into dictionaries

        Args:
            lines (str): \\n separated lines \n
            delimiter (str, optional): delimeter for the line ['\\t', ',','|',':'] Defaults to ','.

        Returns:
            List[Dict]: list of dictionaries corresponding to each parsed row with property names mentioned in headers
        """
        f = io.StringIO(lines)
        reader = csv.reader(f, delimiter=delimiter)
        reader = list(reader)
        return [{self.headers[i]:y for i, y in enumerate(x)} for x in reader]

        # return {rows[0]:rows[1] for rows in reader}
