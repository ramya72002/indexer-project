from topiq_indexer.sources.sftp import SFTPSource
import time
from itertools import islice


class SFTPReader:
    def __init__(self, source: SFTPSource) -> None:
        self.source = source
        pass

    def read(self, filepath, batch_size=0):
        with self.source.client.open(filepath) as file:
            if not batch_size:  # if batch_size==0 means, line by line
                for line in file:
                    yield line
                    time.sleep(0.01)
            else:
                while True:
                    next_n_lines = list(islice(file, 1))
                    yield next_n_lines
