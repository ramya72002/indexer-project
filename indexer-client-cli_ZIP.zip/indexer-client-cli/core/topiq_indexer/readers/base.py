from pandas import DataFrame
import json
from itertools import islice


class FileReader:

    df: DataFrame = None

    def __init__(self) -> None:
        pass

    def read(self, file, batch_size=0):
        f = file
        if type(file) != str:
            f = file
        else:
            f = open(file)

        if batch_size == 0:
            for line in file:
                yield line
        else:
            while True:
                next_n_lines = list(islice(file, batch_size))
                if not next_n_lines:
                    break
                yield next_n_lines
                
        f.close()   

    def to_df(self):
        return self.df

    def to_dict(self):
        return self.dict or self.df.to_dict("records")

    def to_json(self, filepath):
        if self.dict:
            with open(filepath, "w") as file:
                file.write(json.dumps(self.dict))
            return
        return self.df.to_json(filepath, orient="records")

    def to_csv(self, filepath):
        return self.df.to_csv(filepath, index=False)

    def to_xml(self, filepath):
        return self.df.to_xml(filepath)

    def to_excel(self, filepath):
        return self.df.to_excel(filepath)
