import io
import pandas as pd
from .base import FileReader
import xmltodict

class XMLReader(FileReader):
    def __init__(self, text=None, filepath=None) -> None:
        if text:
            self.text = text
        elif filepath:
            with open(filepath) as file:
                self.text = file.read()

        self.file = io.StringIO(self.text)
        self.dict = xmltodict.parse(self.text,attr_prefix='')
