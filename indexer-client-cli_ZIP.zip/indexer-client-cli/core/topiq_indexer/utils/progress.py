from tqdm import tqdm
import time

class Progress:
    def __init__(self,total=None) -> None:
        self.total = total
        self.pbar = tqdm(total=self.total,leave=True,position=0)
        self.last_progress = 0
        self.last_total = total

    def update_progress(self,completed,total):
        # Adding sleep, otherwise throws garbage packet error
        # time.sleep(0.01)
        if self.last_total!=total:
            self.last_total = total
            self.pbar.reset(total=total)
        updatable = completed - self.last_progress
        self.last_progress = completed
        self.pbar.update(updatable)
        