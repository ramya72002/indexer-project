from concurrent.futures import ThreadPoolExecutor
import asyncio
import nest_asyncio
nest_asyncio.apply()
import requests

from timeit import default_timer

START_TIME = default_timer()

async def start_async_process(func,data):
    with ThreadPoolExecutor(max_workers=15) as executor:
        with requests.Session() as session:
            loop = asyncio.get_event_loop()
            START_TIME = default_timer()
            
            tasks = [
                loop.run_in_executor(
                    executor,
                    func,
                    *(session,i,doc)
                )
                for i,doc in enumerate(data)
            ]
            
            for response in await asyncio.gather(*tasks):
                op = response
            END = default_timer()
            print("Done in ",END-START_TIME)

def execute_parallel(func,data):
    loop = asyncio.get_event_loop()
    asyncio.set_event_loop(loop)
    future = asyncio.ensure_future(start_async_process(func,data))
    output = loop.run_until_complete(future)
    
def execute_sync(func,data):
    for i,d in enumerate(data):
        func(None,i,d)