import enum
from uuid import UUID
from typing import Union, List, Dict
from pydantic import BaseModel
from joblib import Parallel,delayed

class IndexingType(str, enum.Enum):
    BATCH = "batch"
    DOC = "doc"


class Event(str, enum.Enum):
    CREATE = "CREATE"
    PARTIAL_UPDATE = "PARTIAL_UPDATE"
    REPLACE = "REPLACE"
    DELETE = "DELETE"


class Batch:
    items: List
    size_bytes: int

class Message(BaseModel):
    event_type: Event
    app_id: UUID
    payload: Union[List, Dict]


class Create(Message):
    event_type = Event.CREATE


class Delete(Message):
    event_type = Event.DELETE


class Replace(Message):
    event_type = Event.REPLACE
