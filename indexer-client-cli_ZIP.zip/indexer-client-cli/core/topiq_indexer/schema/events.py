from pydantic import BaseModel

class IndexingEvent(BaseModel):
    event_type: str
    app_id: str
    payload: dict
    upsert: bool = True