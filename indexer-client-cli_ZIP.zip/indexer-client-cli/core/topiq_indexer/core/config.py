from starlette.config import Config

config = Config(".env")

INDEXER_BASE_URL = config(
    "INDEXER_BASE_URL", default="https://api-dev.topiq.ai/indexer-api")
INDEXER_PUBLISH = config("INDEXER_BASE_URL", default="/publish")
INDEXER_BATCH_PUBLISH = config("INDEXER_BASE_URL", default="/batch/publish")
AUTH_BASE_URL = config("AUTH_BASE_URL", default="https://auth-dev.topiq.ai")
AUTH_OAUTH = config("AUTH_OAUTH", default="/oauth/token")
AUTH_REFRESH_TOKEN = config(
    "AUTH_REFRESH_TOKEN", default="/v1/auth/token/refresh")
AUTH_INFO_TOKEN = config("AUTH_INFO_TOKEN", default="/v1/users/me")

MQ_MANAGER = config("MQ_MANAGER", default="QM1")
MQ_CHANNEL = config("MQ_CHANNEL", default='DEV.APP.SVRCONN')
MQ_HOST = config("MQ_HOST", default='0.tcp.in.ngrok.io')
MQ_PORT = config("MQ_PORT", default="17192")
MQ_SOURCE_FEED_QUEUE = config("MQ_SOURCE_FEED_QUEUE", default='DEV.QUEUE.1')

PINCODE_SERVICE_URL = config(
    "PINCODE_SERVICE_URL", default="http://localhost:8000")

PINCODE_SERVICE_CREATE_DATA = config(
    "PINCODE_SERVICE_CREATE_DATA", default="/create_source_data")
