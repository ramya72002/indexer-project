from topiq_indexer.clients.auth import AuthClient
import requests
from topiq_indexer.core.config import INDEXER_BASE_URL, INDEXER_BATCH_PUBLISH, INDEXER_PUBLISH
from topiq_indexer.schema.indexer import IndexingType
from topiq_indexer.utils.timing import set_timeout
from threading import Timer
from topiq_indexer.utils.multithreading import execute_parallel
from topiq_indexer.targets.http import HTTPTarget
import asyncio
import json
import time
import sys

request_body_template = {
    "event_type": "CREATE",
    "app_id": "",
    "payload": None,
    "upsert": True
}

publish_url = f"{INDEXER_BASE_URL}{INDEXER_PUBLISH}"

batch_publish_url = f"{INDEXER_BASE_URL}{INDEXER_BATCH_PUBLISH}"


class IndexerClient:

    def __init__(self, auth_client: AuthClient) -> None:
        self.auth_client = auth_client
        self.http_target = HTTPTarget(url=batch_publish_url,headers=auth_client.headers)
        self.tasks = []
        self.batch_size_bytes = 0
        self.batch = []
        self.start_time = time.time()
        self.batch_set = []
        self.docs_count = 0
        self.indexed_docs = 0
        self.timer: Timer = None
        self.batch_set_timer: Timer = None

    def index_batch(self, session, i, batch):
        print("INDEXED DoCS", self.indexed_docs)
        print("ELapsed", time.time()-self.start_time)
        body = {**request_body_template}
        body["payload"] = batch
        body["app_id"] = self.auth_client.credentials["app_id"]
        url = batch_publish_url
        # print("HEADERS",self.auth_client.headers)
        res = session.post(url, headers=self.auth_client.headers, json=body)
        if res.status_code != 200:
            print("ERROR in indexing")
            # print(res.request.headers)
            print(res.content)
        else:
            print("SUCCESS")
            res = res.json()
            return res

    # def index_batches(self):
    #     execute_parallel(self.index_batch, self.batch_set)

    def index_batches(self):
        print("BULK SEND")
        print("INDEXED DoCS", self.indexed_docs)
        batches = []
        for batch in self.batch_set:
            d = {}
            d["payload"] = batch
            d["app_id"] = self.auth_client.credentials["app_id"]
            d["event_type"] ="CREATE"
            d["upsert"] = True
            # print(json.dumps(d,indent=2))
            # sys.exit(0)
            batches.append(d)
        failed = self.http_target.bulk_send(batches)
        print("FAILED",failed)

    def push_remaining_batch_sets(self):
        print("PUSHING Remaining batch_sets", len(self.batch_set))
        self.index_batches()
        self.indexed_docs += sum([len(batch) for batch in self.batch_set])
        self.batch_set = []
        # self.push()

    def push_remaining(self):
        print("PUSHING Remaining docs", len(self.batch))
        print(f"BY THIS TIME batch_set = {self.batch_set}")
        self.index_batch(requests, 0, self.batch)
        self.indexed_docs += sum([1 for doc in self.batch])
        # self.push()

    def push(self):
        if self.batch_set_timer and self.batch_set_timer.isAlive():
            self.batch_set_timer.cancel()
            self.batch_set_timer = None
        print("PUSHING DATA", len(self.batch), self.batch_size_bytes)
        self.batch_set.append([*self.batch])
        self.batch = []
        self.batch_size_bytes = 0
        # print("LEN",len(self.batch_set))
        if len(self.batch_set) == 5:
            print("TIME TO CALL API")
            self.index_batches()
            self.indexed_docs += sum([len(batch) for batch in self.batch_set])
            self.batch_set = []
        self.batch_set_timer = set_timeout(self.push_remaining_batch_sets, 2)

    def add(self, doc):
        self.docs_count += 1
        if self.timer and self.timer.isAlive():
            self.timer.cancel()
            self.timer = None
        if self.batch_size_bytes >= 5*1024*1024:
            self.push()
        self.batch.append(doc)
        try:
            self.batch_size_bytes += len(json.dumps(doc))
        except:
            print("ISSUE in doc", doc)
            raise Exception("EXCEPT")
        self.timer = set_timeout(self.push_remaining, 2)

    def _publish(self, data, batch=True):  # data can be a doc or list
        self.batch_size = 0
        body = {**request_body_template}
        body["payload"] = data
        url = batch_publish_url if batch else publish_url
        res = requests.post(url, headers=self.auth_client.headers, json=body)
        if res.status_code != 200:
            print(res.content)
        else:
            res = res.json()
            return res

    def publish_doc(self, batch: dict):
        response = self._publish(batch, batch=False)

    def publish_batch(self, batch: list):
        response = self._publish(batch, batch=True)
