import requests
from topiq_indexer.core.config import AUTH_BASE_URL, AUTH_OAUTH,AUTH_REFRESH_TOKEN,AUTH_INFO_TOKEN
import json
from time import time
from threading import Timer
from topiq_indexer.utils.timing import set_interval,set_timeout

base_url = AUTH_BASE_URL

oauth_url = f"{base_url}{AUTH_OAUTH}"
refresh_url = f"{base_url}{AUTH_REFRESH_TOKEN}"
info_url = f"{base_url}{AUTH_INFO_TOKEN}"

REFRESH_INTERVAL = 4*60 # 4 minutes

class AuthClient:
    def rotate_token(self):
        body = {"refresh_token":self.tokens["refresh_token"]}
        response = requests.post(refresh_url,json=body,headers=self.headers)
        self.tokens = {**response.json(),"updated":time()}
        # print("TOKENS",self.tokens)

    def get_info(self):
        response = requests.get(info_url,headers=self.headers)
        return response.json()

    def __init__(self,credentals:str) -> None:
        print("INIT AUTH")
        with open(credentals) as creds:
            self.credentials = json.load(creds)
        response = requests.post(oauth_url,json=self.credentials)
        print(response.text)
        self.tokens = response.json()
        self.headers = {"Authorization":"Bearer "+self.tokens["access_token"]}
        set_interval(self.rotate_token,REFRESH_INTERVAL)
        self.info = self.get_info()


    
