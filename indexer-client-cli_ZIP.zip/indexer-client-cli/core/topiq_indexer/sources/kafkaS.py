from kafka import KafkaConsumer

class KafkaSource:
    def __init__(self) -> None:
        self.consumer = KafkaConsumer("search",bootstrap_servers=["192.168.0.15:9092"])
        # self.consumer.subscribe("search")

    def watch(self):
        print("WATCHING")
        for msg in self.consumer:
            print(msg)