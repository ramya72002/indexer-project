from itertools import islice
import pysftp
from typing import List, Callable, Dict
import time
from os import stat_result,stat as file_stat
from threading import Thread
from topiq_indexer.utils.progress import Progress
from topiq_indexer.sources.base import Source
import functools
import inspect


cnopts = pysftp.CnOpts()
cnopts.hostkeys = None

class FTPSource(Source):
    def __init__(self, hostname, username, password,port=22, chunk_size=1000) -> None:
        self.client = pysftp.Connection(
            hostname, username=username, password=password,port=port, cnopts=cnopts
        )

    def open(self,*args,**kwargs):
        return self.client.open(*args,**kwargs)

    def read(self, filepath, batch=False):
        with self.client.open(filepath) as file:
            print("STARTING TO READ")
            if not batch:
                for line in file:
                    yield line
                    time.sleep(0.01)
                    # continue
                return
            while True:
                next_n_lines = list(islice(file, 1))
                if not next_n_lines:
                    break
                if not batch:
                    for line in next_n_lines:
                        yield line
                else:
                    yield next_n_lines
    
    def download(self,filepath,destination=None):
        if not destination:
            destination = filepath
        progress = Progress()
        print("GETTING FILE",filepath)
        self.client.get(filepath,destination,callback=progress.update_progress)
    
    def upload(self,filepath,destination=None):
        if not destination:
            destination = filepath
        print("Uploading File",filepath)


    def __watch(self, filename):
        while True:
            time.sleep(5)
            new_stats = self.client.stat(filename)
            old_stats = self.stats[filename]
            if new_stats.st_mtime > old_stats.st_mtime and new_stats.st_size > 0:
                worker_thread = Thread(
                    target=self.subscribers[filename], args=(filename,))
                worker_thread.start()
                self.stats[filename] = new_stats
    

FTPSource.open.__signature__ = inspect.signature(pysftp.Connection.open)