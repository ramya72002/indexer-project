from itertools import islice
import json
import os
import stat
import time
from threading import Thread
from topiq_indexer.sources.base import ResourceType


class FileSource:
    def __init__(self, filepath, chunk_size=1000) -> None:
        self.filepath = filepath
        self.chunk_size = chunk_size
        self.stats = os.stat(filepath)
        self.type: ResourceType = ResourceType.directory if os.path.isdir(
            filepath) else ResourceType.file
        if self.type == ResourceType.directory:
            raise Exception(
                "Watch for directory is not supported. constructor of FileSource should be a valid file location")
        self.watcher_thread: Thread = None
        self.callback_threads = []
        self.subscribers = []

    def read(self, return_json, batch=False):
        with open(self.filepath) as file:
            while True:
                next_n_lines = list(islice(file, self.chunk_size))
                if not next_n_lines:
                    break
                if not batch:
                    for line in next_n_lines:
                        yield json.loads(line) if return_json else line
                else:
                    lines = []
                    for line in next_n_lines:
                        lines.append(json.loads(line) if return_json else line)
                    yield lines

    @property
    def batches(self, return_json=True):
        for data in self.read(batch=True, return_json=return_json):
            yield data

    @property
    def docs(self, return_json=True):
        for data in self.read(batch=False, return_json=return_json):
            yield data

    def _watch(self):
        while True:
            stats = os.stat(self.filepath)
            if stats.st_mtime > self.stats.st_mtime and stats.st_size > 0:
                print("FILE CHANGED")
                self.stats = stats
                self.callback_threads = [
                    Thread(target=x) for x in self.subscribers]
                print(len(self.callback_threads), "Threads started")
                for thread in self.callback_threads:
                    thread.start()
                time.sleep(5)

    def onchange(self, func):
        if func in self.subscribers:
            return
        else:
            self.subscribers.append(func)
            print(f"Listener Added, Total:{len(self.subscribers)}")
            if self.watcher_thread:
                self.watcher_thread.join()
            self.watcher_thread = Thread(target=self._watch)
            self.watcher_thread.start()
