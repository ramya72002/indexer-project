from abc import ABC, abstractmethod
from pydantic import BaseModel
from typing import Callable, List, Any
from enum import IntEnum
import os
import signal
from threading import Thread


class ResourceType(IntEnum):
    file = 1
    directory = 2


class WatchResponse(BaseModel):
    name: str


class Subscriber(BaseModel):
    name: str
    callback: Callable
    stats: Any = None


class Source:

    subscribers: List[Subscriber] = []
    threads: List[Thread] = []

    def watch_handler(self, subscriber: Subscriber, callback: Callable,*args):
        pass

    def watch(self, item: str,*args):
        def decorator(callback):
            if item in [x.name for x in self.subscribers]:
                print(
                    f"ERROR: You can only add 1 listener. Found more than 1 for '{item}'")
                os.kill(os.getpid(), signal.SIGKILL)
            else:
                new_sub = Subscriber(
                    name=item, callback=callback, stats=None)
                self.subscribers.append(new_sub)
                print(
                    f"Listening to {item}, Total:{len(self.subscribers)}")
                thread = Thread(target=self.watch_handler, args=(new_sub, callback,*args))
                thread.start()
        return decorator
