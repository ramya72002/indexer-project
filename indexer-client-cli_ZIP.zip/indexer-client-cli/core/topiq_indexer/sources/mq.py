import pymqi
from threading import Thread
import time
from typing import Callable
from .base import Subscriber, Source
from topiq_indexer.utils.timing import set_timeout

class MQSource(Source):
    def __init__(self, queue_manager: str, channel: str, host: str, port: str) -> None:
        self.host = f'{host}({port})'
        self.queue_manager = queue_manager
        self.channel = channel
        # self.connection = pymqi.connect(queue_manager, channel, host)
        self.watch_queues = []
        self.watcher_thread:Thread = None
        self.timer = None

    # def watch(self,queue,batch_size=10,*args):
    #     def decorator(callback):
    #         self.watch_queues.append({"name":queue,"callback":callback,"batch_size":batch_size})
    #         if(self.watcher_thread and self.watcher_thread.is_alive()):
    #             self.watcher_thread.join()
    #             self.watcher_thread = None
    #         self.watcher_thread = Thread(target=self.watch_handler,args=(self.watch_queues,*args,))
    #         self.watcher_thread.start()
    #     return decorator

    def watch_handler(self, subscriber: Subscriber, callback, *args):
        queue_name = subscriber.name
        batch_size = args[0] if args else 10
        # It is required to create a different connection inside a thread otherwise it throws error
        # MQI Error. Comp: 2, Reason 2018: FAILED: MQRC_HCONN_ERROR
        connection = pymqi.connect(self.queue_manager, self.channel, self.host)
        queue = pymqi.Queue(connection, queue_name)
        while True:
            messages = []
            try:
                for i in range(batch_size):
                    m = queue.get()
                    messages.append(m)
            except:
                pass
            finally:
                if len(messages)>0:
                    callback({"queue": queue_name, "messages": messages})
            time.sleep(5)
        # if os.path.isdir(subscriber.name):
        #     print(
        #         "Can't listen to a directory, please add a valid file location")
        #     os.kill(os.getpid(), signal.SIGKILL)
        # stats = os.stat(subscriber.name)
        # subscriber.stats = stats
        # while True:
        #     stats = os.stat(subscriber.name)
        #     if stats.st_mtime > subscriber.stats.st_mtime and stats.st_size > 0:
        #         subscriber.stats = stats
        #         callback(subscriber.name)
        #         time.sleep(5)

    # def watch_handler(self, watch_queues,batch_size: int = 10):
    #     # It is required to create a different connection inside a thread otherwise it throws error
    #     # MQI Error. Comp: 2, Reason 2018: FAILED: MQRC_HCONN_ERROR
    #     connection = pymqi.connect(self.queue_manager, self.channel, self.host)
    #     watch_queues = { x["name"]:{**x,"queue":pymqi.Queue(connection, x["name"])} for x in self.watch_queues}
    #     callbacks = {x:watch_queues[x]["callback"] for x in watch_queues}
    #     while True:
    #         try:
    #             messages = {}
    #             # for i in watch_queues:
    #             #     q = i["queue"]
    #             #     queue = i["name"]
    #             #     callback = i["callback"]
    #             #     messages = []
    #             #     try:
    #             #         for i in range(batch_size):
    #             #             message = q.get()
    #             #             messages.append(message)
    #             #     finally:
    #             #         if len(messages)>0:
    #             #             callback({"queue": queue, "messages": messages})
    #         except Exception as e:
    #             if "2033" not in str(e):
    #                 print(e)
    #         time.sleep(5)
