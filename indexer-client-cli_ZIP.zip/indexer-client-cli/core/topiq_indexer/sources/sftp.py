from itertools import islice
import pysftp
import re
from typing import List, Callable, Dict
import time
from os import stat_result, stat as file_stat
from threading import Thread
from topiq_indexer.utils.progress import Progress
from topiq_indexer.sources.base import Source, Subscriber
import functools
import inspect


cnopts = pysftp.CnOpts()
cnopts.hostkeys = None


class SFTPSource(Source):
    def __init__(self, hostname, username, password, port=22, chunk_size=1000) -> None:
        self.hostname = hostname
        self.username = username
        self.password = password
        self.port = port
        self.chunk_size = chunk_size
        self.build_connection()

    def build_connection(self):
        self.client = pysftp.Connection(
            self.hostname, username=self.username, password=self.password, port=self.port, cnopts=cnopts
        )

    def open(self, *args, **kwargs):
        return self.client.open(*args, **kwargs)

    def read(self, filepath, batch_size=10):
        with self.client.open(filepath) as file:
            while True:
                next_n_lines = list(islice(file, batch_size))
                if not next_n_lines:
                    break
                yield next_n_lines

    def download(self, filepath, destination=None):
        if not destination:
            destination = filepath
        progress = Progress()
        print("GETTING FILE", filepath)
        self.client.get(filepath, destination,
                        callback=progress.update_progress)

    def upload(self, filepath, destination=None):
        if not destination:
            destination = filepath
        print("Uploading File", filepath)

    def __get_files_with_matching_pattern(self, pattern):
        d = pattern.split("/")
        file = d[-1]
        # print("FILENAME",file)
        file_pattern = re.escape(file).replace("\*", ".*")
        regex = re.compile(file_pattern)
        directory = "/".join(d[:-1]) or ""
        # print("DIR",directory)
        if directory:
            files = self.client.listdir(directory)
        else:
            files = self.client.listdir()

        matched_files = [x for x in files if re.match(regex, x)]
        # print("MATCHED 1",matched_files)
        # append dir name
        if directory:
            matched_files = [directory+"/"+x for x in matched_files]
        # filter out only files, not directories
        matched_files = [x for x in matched_files if self.client.isfile(x)]
        # print("MATCHED",matched_files)
        return matched_files

    def watch_handler(self, subscriber: Subscriber, callback, *args):
        files = []
        watch_type = "single"
        if "*" in subscriber.name:
            # print("multiple")
            watch_type = "multiple"
            files = self.__get_files_with_matching_pattern(subscriber.name)
            print("WATCHING", len(files), "matched files.")
            # print("FILES",files)
        else:
            files = [subscriber.name]
        # print("FILES",files)

        file_stats = {x: self.client.stat(x) for x in files}
        # print("STATS_f",file_stats)

        while True:
            time.sleep(5)
            # check for new additions
            new_files = self.__get_files_with_matching_pattern(subscriber.name)
            # print("FILES",new_files)
            if new_files != files:
                # print("CHANGED")
                print("CHANGED files, watching", len(
                    new_files), "matched files.")
                changed_files = list(set(new_files) - set(files))
                files = new_files
                file_stats = {x: self.client.stat(x) for x in files}
                callback(changed_files)
                self.build_connection()
                continue

            changed_files = []
            for filename in files:
                new_stats = self.client.stat(filename)
                old_stats = file_stats[filename]
                if new_stats.st_mtime > old_stats.st_mtime and new_stats.st_size > 0:
                    # print("CHANGED")
                    changed_files.append(filename)
                    file_stats[filename] = new_stats

            if len(changed_files) > 0:
                callback(changed_files[0] if watch_type ==
                         "single" else changed_files)
                self.build_connection()


SFTPSource.open.__signature__ = inspect.signature(pysftp.Connection.open)
