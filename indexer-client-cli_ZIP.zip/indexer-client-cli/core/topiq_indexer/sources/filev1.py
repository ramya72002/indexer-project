from typing import Callable, List
from pydantic import BaseModel
from threading import Thread
import os
import signal
from os import stat_result
from io import FileIO
import time
from .base import Subscriber, Source


class FileSystemSource(Source):
    def __init__(self) -> None:
        pass

    def open(self, filepath, mode="r") -> FileIO:
        return open(file=filepath, mode=mode)

    def watch_handler(self, subscriber: Subscriber, callback, *args):
        if os.path.isdir(subscriber.name):
            print(
                "Can't listen to a directory, please add a valid file location")
            os.kill(os.getpid(), signal.SIGKILL)
        stats = os.stat(subscriber.name)
        subscriber.stats = stats
        while True:
            stats = os.stat(subscriber.name)
            if stats.st_mtime > subscriber.stats.st_mtime and stats.st_size > 0:
                subscriber.stats = stats
                callback(subscriber.name)
                time.sleep(5)
