from io import StringIO
import csv

class CSVConverter:
    def __init__(self, line, file=None) -> None:
        pass
