class SearchEvent:
    pass

class ClickEvent:
    pass