import json


class JSONConverter:

    def __init__(self, string, file=None) -> None:
        if file:
            return json.load(open(file))
        return json.loads(string)
