from .event import Event
from schema.events import SearchEvent, CartEvent, SortEvent, OrderEvent, FilterEvent, PDPEvent, WhishlistEvent, AutoSuggestEvent

models = {
    Event.CART: CartEvent,
    Event.SEARCH: SearchEvent,
    Event.SORT: SortEvent,
    Event.ORDER: OrderEvent,
    Event.FILTER: FilterEvent,
    Event.PDP: PDPEvent,
    Event.WHISHLIST: WhishlistEvent,
    Event.AUTOSUGGEST: AutoSuggestEvent
}
