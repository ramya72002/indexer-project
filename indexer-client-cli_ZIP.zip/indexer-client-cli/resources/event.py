import enum

class Attribute:
    whishlist = 'wishlist:added'
    filter = "filter_clicked"
    sort = 'sortby'

class Event:
    SEARCH = "SearchEvent" 
    CART = "CartEvent"
    ORDER = "OrderEvent" 
    AUTOSUGGEST = "AutosuggestEvent" 
    PDP = "PDPEvent" 
    FILTER = "FilterEvent" 
    WHISHLIST = "WhishlistEvent"
    SORT = "SortEvent" 