from resources.event import Event

mappings = {
    "ECID (evar1)": "session_id",
    "Customer ID (evar6)": "session_user_id",
    "Time Stamp (prop3)": "event_time",
    "Search Term (evar18)": "search_term",
    "Autosuggestion Search Keyword (evar105)": "auto_suggestion_prefix",
    "Autosuggestion Product Name (evar106)": "auto_suggestion_term",
    "Num of Products Found (evar22)": "quantity",
    "Cities": "location",
    "Previous Page Name (prop4)": "previous_page",
    "Link Type (evar16)": "link_type",
    "Link Name (evar15)": "link_name",
    "Link Position (evar17)": "link_position",
    "Product SKU (evar10)": "product_id",
    "Mobile Device Type": "device",
    "Price (evar13)": "price",
    "Product Rank (event19)": "product_rank",
    "Buy Now (event60)": "buynow_event",
    "Cart Additions": "cart_event",
    "Search (event6)": "search_event",
    "Orders": "order_event",
    "Product Views": "product_view"
}


def mapped_fields(fields: dict):
    return {mappings.get(x, x): y for x, y in fields.items()}


extras = {
    Event.SEARCH: {
        "quantity": "search_res_count"
    },
    Event.SORT: {
        "link_name": "sort"
    },
    Event.PDP: {
        "product_view": "click_position"
    }
}


def map_event_fields(fields: dict, event: str):
    mapping = extras.get(event)
    if not mapping:
        return fields
    return {mapping.get(x, x): y for x, y in fields.items()}
